appmaker-components
===================

Issues for this project are currently tracked at https://github.com/mozilla/appmaker/issues