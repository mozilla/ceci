Building-Blocks
===============

Reusable components for Firefox OS

'style' and 'style_unstable' folders contain all Building Blocks from [gaia's repo](https://github.com/mozilla-b2g/gaia).
Feel free to use them, although we are using the word 'unstable' :) 

These two folders are copied using subtree merge strategy, so basicaly you will be cloning the whole gaia, so when you clone it for the first time it will take a while to download. Updates will be much faster!


